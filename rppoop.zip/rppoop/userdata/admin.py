from django.contrib import admin

from userdata.models import Userdata

class UserdataAdmin(admin.ModelAdmin):
    list_display=('Name','PhoneNo','City','Email','Message')

admin.site.register(Userdata,UserdataAdmin)
