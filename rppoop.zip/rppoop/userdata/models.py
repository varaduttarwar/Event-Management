# models.py
from django.db import models

class Userdata(models.Model):
    Name = models.CharField(max_length=100)
    PhoneNo = models.IntegerField()
    City = models.CharField(max_length=50)
    Email = models.CharField(max_length=100)
    Message = models.TextField()
