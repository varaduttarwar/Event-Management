from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('about-us/', views.aboutUs),
    path('course/', views.course),
    path('course/<courseid>', views.courseDetails),
    path('', views.homepage),
    #path('contact-us/', views.contactUs),  # Changed URL to match view name
    #path('send_email/', views.sendEmail),  # Changed URL to match view name
   # path('contact/', views.contact_view, name='contact'),
    path('contact-us/', views.contacts),
    path('saveenquiry/', views.saveEnquiry,name="saveenquiry"),
    path('wedding-us/', views.weddings),
    path('product-us/', views.products),
    path('award_ceremony/', views.awards),
    path('artist_management/', views.artist_),
    path('artist_management/', views.artist_),
    path('birthday/', views.birthday_),
    
]


