import os
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from django.core.mail import send_mail
from django.conf import settings
from userdata.models import Userdata

#def contacts(request):
 #     email = request.POST['email']
  #      message = request.POST['message']
#
 #       # Save the data to the database
#
 #       return redirect('contacts')
##
  #  return render(request, 'contact.html')

def homepage(request):
   
    return render(request,"index.html")


def aboutUs(request):
    return render(request,"aboutUss.html")

def course(request):
    return HttpResponse("welcome to our course")


def courseDetails(request,courseid):
    return HttpResponse(courseid +1)

def contacts(request):
    return render(request,"contactUs.html")

def sendEmail(request):
    return render(request,"send_email.html")

def saveEnquiry(request):
    if request.method=="POST":
        name=request.POST.get('name')
        phone=request.POST.get('phone')
        city=request.POST.get('city')
        email=request.POST.get('email')
        message=request.POST.get('message')
        en=Userdata(Name=name,PhoneNo=phone,City=city,Email=email,Message=message)
        en.save()
    return render(request,"contactUs.html")

def weddings(request):
    return render(request,"wedding.html")

def products(request):
    return render(request,"product.html")

def awards(request):
    return render(request,"award.html")

def artist_(request):
    return render(request,"artist1.html")

def birthday_(request):
    return render(request,"birthday1.html")


    
